/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vice-wra <vice-wra@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/03 17:20:59 by vice-wra          #+#    #+#             */
/*   Updated: 2019/08/03 18:10:58 by vice-wra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "include/lem_in.h"

int get_ants_count(char *line)
{
	while (*line)
	{
		if (!ft_isdigit(*line))
			return -1;
		line++;
	}
	return (ft_atoi(line));
}

int check_each_char(char *line)
{
	while (*line)
	{
		if (!ft_isalnum(*line))
			return (-1);
		line++;
	}
	return (0);
}

int check_line(char *line)
{
	char **str;

	if (ft_strequ(line, "##start"))
		return (1);
	else if (ft_strequ(line, "##end"))
		return (2);
	else if (ft_strchr(line, '-'))
	{
		str = ft_strsplit(line, '-');
		if (str[2] != NULL || check_each_char(str[0]) == -1 || check_each_char(str[1] == -1))
			return (-1);
		return (3);
	}
	if (check_each_char(line) == -1)
		return (-1);
	return (0);
}

int parse_line(t_graph *g, char *line, int flag)
{
	char **str;
	int i;
	int ret;
	
	str = ft_strsplit(line, ' ');
	ret = check_line(str[0]);
	if (ret == -1)
		return (-1);
	if (ret == 1)
		return 1;
	else if (ret == 2)
		return 2;
	if (flag == 1)
		graph_add_start_vert(g, str[0]);
	else if (flag == 2)
		graph_add_end_vert(g, str[0]);


	
}


void parse_main()
{
	int ret;
	char *line;
	t_graph *new_graph;
	int ants_num;
	int flag;

	new_graph = graph_create();
	ret = 0;
	flag = 0;
	if ((ants_num = get_ants_count(get_next_line(0, line))) < 0)
		return ;
	while ((ret = get_next_line(0, line)) == 1)
	{
		flag = parse_line(new_graph, line, flag);
		if (flag == -1)
			return ;
	}
}