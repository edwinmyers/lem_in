/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vice-wra <vice-wra@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/03 17:20:59 by vice-wra          #+#    #+#             */
/*   Updated: 2019/08/05 18:22:25 by vice-wra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/lem_in.h"

t_graph *graph;

int get_size(char **str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int get_ants_count(char *line)
{
	int i;

	i = 0;
	while (line[i])
	{
		if (!ft_isdigit(line[i]))
			return -1;
		i++;
	}
	return (ft_atoi(line));
}

int check_each_char(char *line)
{
	while (*line)
	{
		if (!ft_isalnum(*line))
			return (-1);
		line++;
	}
	return (0);
}

int count_chars(char *str, char c)
{
	int i;
	int count;

	count = 0;
	i = 0;
	while (str[i])
	{	
		if (str[i] == c)
			count++;
		i++;
	}
	return (count);
}

int check_room_name(char *name)
{
	if (check_each_char(name) == -1 || *name == 'L')
			return (-1);
	return (0);
}

int		ft_count_digits(int n)
{
	int i;

	i = 1;
	while ((n = n / 10) != 0)
		i++;
	return (i);
}

int				ft_isnum(char *str)
{
	int			i;
	int			len;
	int			num;

	len = ft_strlen(str);
	num = ft_atoi(str);
	if (!ft_isdigit(str[0]) && len == 1)
		return (0);
	i = ft_count_digits(num) + (num < 0 ||
	(str[0] == '+' && ft_isdigit(str[1])) ? 1 : 0);
	if (i != len)
		return (0);
	return (1);
}

int check_coors(char *first_coor, char *second_coor)
{
	int i;

	i = 0;
	if (!ft_isnum(first_coor) || !ft_isnum(second_coor))
		return (-1);
	return (0);
}

int check_line(char *line)
{
	char **str;

	if (ft_strequ(line, "##start"))
		return (1);
	else if (ft_strequ(line, "##end"))
		return (2);
	else if (line[0] == '#')
		return (0);
	else if (ft_strchr(line, '-'))
	{
		str = ft_strsplit(line, '-');
		if (get_size(str) != 2 || check_each_char(str[0]) == -1 || check_each_char(str[1]) == -1 || count_chars(line, '-') != 1)
			return (-1);
		return (3);
	}
	str = ft_strsplit(line, ' ');
	if (get_size(str) != 3 || check_room_name(str[0]) == -1 || check_coors(str[1], str[2]) == -1)
		return -1;
	return (0);
}


void parse_line(t_dict *rooms, char *line, int flag, int idx)
{
	char **str;

	if (flag != 3)
	{
		str = ft_strsplit(line, ' ');
		dict_insert(rooms, str[0], idx);
		if (flag == 1)
			graph_add_start_vert(graph, str[0]);
		else if (flag == 2)
			graph_add_end_vert(graph, str[0]);
		else 
			graph_add_vert(graph, str[0]);
		ft_strdel(str);
	}
	else
	{
		str = ft_strsplit(line, '-');
		graph_add_edge(graph, dict_at(rooms, str[0]), dict_at(rooms, str[1]));
	}
}

#include <stdio.h>
t_graph *parse_main()
{
	char *line;
	int idx;
	t_dict *rooms;
	int flag;
	int ant_count;
	
	graph = graph_create();
	get_next_line(0, &line);
	ant_count = get_ants_count(line);
	if (ant_count <= 0)
		return (NULL);
	rooms = dict_create();
	idx = 0;
 	while(get_next_line(0, &line))
	{
		flag = check_line(line);
		if (flag == -1)
			return (NULL);
		else if (flag == 1 || flag == 2)
		{
			get_next_line(0, &line);
			if ((check_line(line) == -1 || (flag == 2 && graph->end_idx != -1) || (graph->start_idx != -1 && flag == 1)))
			{
				graph_destroy(&graph);	
				return (NULL);
			}
		}
		parse_line(rooms, line, flag, idx);
		idx++;
	}
	return (graph);
}